ALTER DEFINER=`root`@`%` EVENT MARS40.nbu_event ENABLE;

